cars.csv:
=========
from: http://archive.ics.uci.edu/ml/datasets/Auto+MPG

iris.csv:
=========
from: http://code.google.com/p/dataminingproject/source/browse/DataMiningApp/datasets/Iris/iris.csv?r=44

weather.csv:
=========
from: Kantardzic, M.: Data mining : concepts, models, methods, and algorithms. Wiley, NY, 2011.


Get additional data for WEKA:
http://storm.cis.fordham.edu/~gweiss/data-mining/datasets.html
